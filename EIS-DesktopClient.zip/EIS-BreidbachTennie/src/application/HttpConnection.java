package application;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpConnection {
	
	public HttpConnection(){
		
	}
	
	public static String post(String targetURL, String urlParameters){
		URL url;
		HttpURLConnection connection = null;  
		try {
		    //Verbindung wird erstellt (POST)
		    url = new URL(targetURL);
		    connection = (HttpURLConnection)url.openConnection();
		    connection.setRequestMethod("POST");
		    connection.setRequestProperty("Content-Type", "application/json");
					
		    connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length)); 
					
		    connection.setUseCaches (false);
		    connection.setDoInput(true);
		    connection.setDoOutput(true);
		
		    //Request wird gesendet, Daten werden übergeben
		    DataOutputStream output = new DataOutputStream (connection.getOutputStream ());
		    output.writeBytes (urlParameters);
		    output.flush ();
		    output.close ();
		
		    //Response wird erwartet und die übertragenden Daten werden gespeichert	
		    InputStream input = connection.getInputStream();
		    BufferedReader tempBuffer = new BufferedReader(new InputStreamReader(input));
		    String line;
		    StringBuffer response = new StringBuffer();
		    
		    while((line = tempBuffer.readLine()) != null) {
		    	response.append(line);
		    	response.append('\r');
		    }

		    tempBuffer.close();
		    return response.toString();
		  
		} catch (Exception e) {
			
		    e.printStackTrace();
		    return null;
		    
		} finally {
			
			if(connection != null) {   
				connection.disconnect();    
			}
		}
	}
	
	public static String get(String targetURL){
		URL url;
		HttpURLConnection connection = null;  
		try {
		    //Verbindung wird erstellt (GET)
		    url = new URL(targetURL);
		    connection = (HttpURLConnection)url.openConnection();
		    connection.setRequestMethod("GET");
		    connection.setRequestProperty("Content-Type", "application/json");
		
		    //Response wird erwartet und die übertragenden Daten werden gespeichert	
		    InputStream input = connection.getInputStream();
		    BufferedReader tempBuffer = new BufferedReader(new InputStreamReader(input));
		    String line;
		    StringBuffer response = new StringBuffer();
		    
		    while((line = tempBuffer.readLine()) != null) {
		    	response.append(line);
		    	response.append('\r');
		    }

		    tempBuffer.close();
		    return response.toString();
		  
		} catch (Exception e) {
			
		    e.printStackTrace();
		    return null;
		    
		} finally {
			
			if(connection != null) {   
				connection.disconnect();    
			}
		}
	}
	
	public static String put(String targetURL, String urlParameters){
		URL url;
		HttpURLConnection connection = null;  
		try {
		    //Verbindung wird erstellt (PUT)
		    url = new URL(targetURL);
		    connection = (HttpURLConnection)url.openConnection();
		    connection.setRequestMethod("PUT");
		    connection.setRequestProperty("Content-Type", "application/json");
					
		    connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length)); 
					
		    connection.setUseCaches (false);
		    connection.setDoInput(true);
		    connection.setDoOutput(true);
		
		    //Request wird gesendet, Daten werden übergeben
		    DataOutputStream output = new DataOutputStream (connection.getOutputStream ());
		    output.writeBytes (urlParameters);
		    output.flush ();
		    output.close ();
		
		    //Response wird erwartet und die übertragenden Daten werden gespeichert	
		    InputStream input = connection.getInputStream();
		    BufferedReader tempBuffer = new BufferedReader(new InputStreamReader(input));
		    String line;
		    StringBuffer response = new StringBuffer();
		    
		    while((line = tempBuffer.readLine()) != null) {
		    	response.append(line);
		    	response.append('\r');
		    }

		    tempBuffer.close();
		    return response.toString();
		  
		} catch (Exception e) {
			
		    e.printStackTrace();
		    return null;
		    
		} finally {
			
			if(connection != null) {   
				connection.disconnect();    
			}
		}
	}
	public static String delete(String targetURL){
		URL url;
		HttpURLConnection connection = null;  
		try {
		    //Verbindung wird erstellt (delete)
		    url = new URL(targetURL);
		    connection = (HttpURLConnection)url.openConnection();
		    connection.setRequestMethod("DELETE");
		    connection.setRequestProperty("Content-Type", "application/json");
		
		    //Response wird erwartet und die übertragenden Daten werden gespeichert	
		    InputStream input = connection.getInputStream();
		    BufferedReader tempBuffer = new BufferedReader(new InputStreamReader(input));
		    String line;
		    StringBuffer response = new StringBuffer();
		    
		    while((line = tempBuffer.readLine()) != null) {
		    	response.append(line);
		    	response.append('\r');
		    }

		    tempBuffer.close();
		    return response.toString();
		  
		} catch (Exception e) {
			
		    e.printStackTrace();
		    return null;
		    
		} finally {
			
			if(connection != null) {   
				connection.disconnect();    
			}
		}
	}

}
