package application;

import application.ResteverwertungController;
import application.HttpConnection;
import application.MainUebersichtController;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class RezepteController implements Initializable{

	RESTkoch rKoch = new RESTkoch();
	
	
	public String rezeptId;
	private String id;
	private String datum;
	private String wochentag;
	
	@FXML
	private Label rezeptTitel;
	@FXML
	private Label schwierigkeitsgrad;
	@FXML
	private Label zeitbedarf;
	@FXML
	private Label beschreibung;
	@FXML
	private Label zutaten;
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		id = LoginController.userId;
		rezeptId = MainUebersichtController.ausgewaehltesRezept;
		
		String url = "http://localhost:8080/rezept/" + rezeptId;
		String rezeptGet = HttpConnection.get(url);
		Object temp = JSONValue.parse(rezeptGet);
		JSONObject rezept = (JSONObject) temp;
		JSONArray zutatenRezept = (JSONArray) rezept.get("Zutaten");
		
		rezeptTitel.setText((String) rezept.get("Titel"));
		schwierigkeitsgrad.setText((String) rezept.get("Schwierigkeitsgrad"));
		zeitbedarf.setText((String) rezept.get("Zeitbedarf"));
		beschreibung.setText((String) rezept.get("Beschreibung"));
		//zutaten.setWrapText(true);
		
		String zutatenString ="";
		
		for(int i = 0; i < zutatenRezept.size(); i++){
			JSONObject tempZ = (JSONObject) zutatenRezept.get(i);
			zutatenString = zutatenString + tempZ.get("name") + ": " + tempZ.get("menge") + " " + tempZ.get("mengenangabe") +"\n";
		}
		System.out.println(zutatenString);
		
		//zutaten.setText(zutatenString);
		
		
		
	}
	
	@FXML
	private void addRezept() throws IOException{
		
		datum = MainUebersichtController.ausgewaehltesDatum;
		wochentag = MainUebersichtController.ausgewaehlterWochentag;
		//rezeptId
		
		String urlParameters = "{\"datum\": \"" + datum +"\" , \"rezept\": \"" + rezeptId + "\" , \"tag\": \"" + wochentag + "\"}";
		System.out.println(urlParameters);
		
		
		String url = "http://localhost:8080/user/" + id + "/wochenplan";
		String put = HttpConnection.put(url, urlParameters);
		
		Object test123 = JSONValue.parse(put);
		JSONObject temp = (JSONObject) test123;
		JSONArray finalResult=(JSONArray) temp.get("wochenplan");
		System.out.println(finalResult);
		
		
		rKoch.loadMainview();
		RESTkoch.stage.setScene(RESTkoch.mainUebersicht);
	}
	
	@FXML
	private void zurueck() throws IOException{
		if(MainUebersichtController.fromMain){
			rKoch.loadMainview();
			RESTkoch.stage.setScene(RESTkoch.mainUebersicht);
		} else {
			RESTkoch.stage.setScene(RESTkoch.resteverwertung);
		}
	}
	
	
	
	

}
