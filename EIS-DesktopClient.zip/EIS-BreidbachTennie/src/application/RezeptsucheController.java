package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.RESTkoch;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class RezeptsucheController implements Initializable{

	RESTkoch rKoch = new RESTkoch();
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
	
	@FXML
	private void like (ActionEvent event) throws IOException{
	}
	
	@FXML
	private void dislike (ActionEvent event) throws IOException{
	}
	
	@FXML
	private void vegetarisch (ActionEvent event) throws IOException{
	}

	@FXML
	private void schwierigkeitsgrad (ActionEvent event) throws IOException{
	}
	
	@FXML
	private void dauer (ActionEvent event) throws IOException{
	}
	
	@FXML
	private void suche (ActionEvent event) throws IOException{
	}
	
	@FXML
	private void zufallsrezept (ActionEvent event) throws IOException{
	}
	
}
