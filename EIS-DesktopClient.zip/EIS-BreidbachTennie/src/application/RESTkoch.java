package application;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.JSONValue;

import java.io.IOException;
//import application.Parent;
import javafx.fxml.FXMLLoader;
import javafx.application.Application;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.scene.Scene;
//import javafx.scene.layout.BorderPane;


public class RESTkoch extends Application {
	
    public static String loginScreen = "Login.fxml";
    public static String mainUebersichtScreen = "MainUebersicht.fxml";
    public static String resteverwertungScreen = "Resteverwertung.fxml";
    public static String rezeptsucheScreen = "Rezeptsuche.fxml";
    public static String rezepteScreen = "Rezepte.fxml";
    public static String einkaufszettelScreen = "Einkaufszettel.fxml";
    public static String lebensmittelbestandScreen = "Lebensmittelbestand.fxml";
    
    public static Stage stage;
    public static Scene login, mainUebersicht, resteverwertung, rezeptsuche, rezepte, einkaufszettel, lebensmittelbestand;
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		/*try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}*/
		stage = primaryStage;
		
		loadLogin();
		
        //loadMainview();
		
		//loadEinkaufszettel();
		
		//loadLebensmittelbestand();
        
        //loadResteverwertung();
        
        Parent tempRezeptsuche = FXMLLoader.load(getClass().getResource(rezeptsucheScreen));
        rezeptsuche = new Scene(tempRezeptsuche);
        
        //loadRezepte();
        
        
        primaryStage.setScene(login);
        primaryStage.show();
	}
	
	

	public void loadLogin() throws IOException{
		Parent tempLogin = FXMLLoader.load(getClass().getResource(loginScreen));
        login = new Scene(tempLogin);
	}
	
	public void loadMainview() throws IOException{
		Parent tempMainUebersicht = FXMLLoader.load(getClass().getResource(mainUebersichtScreen));
        mainUebersicht = new Scene(tempMainUebersicht);
	}
	
	public void loadEinkaufszettel() throws IOException{
		Parent tempEinkaufszettel = FXMLLoader.load(getClass().getResource(einkaufszettelScreen));
        einkaufszettel = new Scene(tempEinkaufszettel);
	}
	
	public void loadLebensmittelbestand() throws IOException{
		Parent tempLebensmittelbestand = FXMLLoader.load(getClass().getResource(lebensmittelbestandScreen));
        lebensmittelbestand = new Scene(tempLebensmittelbestand);
	}
	
	public void loadResteverwertung() throws IOException{
		Parent tempResteverwertung = FXMLLoader.load(getClass().getResource(resteverwertungScreen));
        resteverwertung = new Scene(tempResteverwertung);
	}
	
	public void loadRezepte() throws IOException{
		Parent tempRezepte = FXMLLoader.load(getClass().getResource(rezepteScreen));
        rezepte = new Scene(tempRezepte);
	}
	
	
	public static void main(String[] args) {
		/*String url = "http://localhost:8080/users";
		
		String test = get(url);
		
		Object test123 = JSONValue.parse(test);
		JSONArray finalResult=(JSONArray) test123;
		System.out.println(finalResult);
		System.out.println(finalResult.get(0));
		System.out.println(finalResult.size());
		JSONObject bla = (JSONObject) finalResult.get(0);
		System.out.println(bla.get("Benutzername"));*/
		
		launch(args);
		
	}
	

	
	
}
