package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import application.MainUebersichtController;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class EinkaufszettelController implements Initializable{
	
	RESTkoch rKoch = new RESTkoch();
	HttpConnection http = new HttpConnection();
	
	@FXML
	private TabPane einkaufszettel;
	
	
	
	private JSONArray zettel;
	private JSONArray [] kompletteListe = new JSONArray [5];
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
		String id = LoginController.userId;
		
		String url;
		
		String [] rezeptTage = new String [5];
		
		//datum //wochentag //data
		
		
		
		
		// daten überprüfen --> falls null >> ein leeres Array einspeichern
		// den Daten den Wochentag zuweisen (ggf Datum speichern)
		// das Rezept holen was an dem Tag geplant ist
		// die Zutaten herausfiltern
		// die Zutaten für den Tag in der Einkaufsliste speichern --> in die listView einbauen
		// die Zutaten in einer kommpletten Liste speichern
		
		BorderPane borderPane = new BorderPane();
		for(int i = 0; i < MainUebersichtController.wochentag.length; i++){
			Tab tab = new Tab();
			tab.setText(MainUebersichtController.wochentag[i]);
			if(MainUebersichtController.data[i] != null){
				
				String rezeptid = (String) MainUebersichtController.data[i].get("rezept");
				
				url = "http://localhost:8080/rezept/" + rezeptid;
				String rezeptGet = HttpConnection.get(url);
				Object temp = JSONValue.parse(rezeptGet);
				JSONObject rezept = (JSONObject) temp;
				JSONArray zutatenRezept = (JSONArray) rezept.get("Zutaten");
			
				
				TableView<Zutat> tabelle = new TableView<Zutat>();
				ObservableList<Zutat> data = FXCollections.observableArrayList();
				
				for(int k = 0; k < zutatenRezept.size(); k++){
					JSONObject zutat = (JSONObject) zutatenRezept.get(k);
					
					String name = (String) zutat.get("name");
					String menge = (String) zutat.get("menge");
					String mengenangabe = (String) zutat.get("mengenangabe");
					
					data.add(new Zutat(name, menge, mengenangabe));
					tabelle.setItems(data);
				}
				tabelle.setPrefSize(646, 368);
				HBox hbox = new HBox();
		        hbox.getChildren().add(tabelle);
		        //hbox.setPrefWidth(646);
		        //hbox.setPrefHeight(368);
		        hbox.setAlignment(Pos.CENTER);
				tab.setContent(hbox);
				
				rezeptTage[i] = MainUebersichtController.wochentag[i];
				
				TableColumn zutatName = new TableColumn("Zutat");
				zutatName.setCellValueFactory(new PropertyValueFactory<Zutat, String>("name"));
				
				TableColumn zutatMenge = new TableColumn("Menge");
				zutatMenge.setCellValueFactory(new PropertyValueFactory<Zutat, String>("menge"));
				
				TableColumn zutatMengenangabe = new TableColumn("Mengenangabe");
				zutatMengenangabe.setCellValueFactory(new PropertyValueFactory<Zutat, String>("mengenangabe"));
				
				tabelle.getColumns().addAll(zutatName, zutatMenge, zutatMengenangabe);
				
			} else {
				HBox hbox = new HBox();
		        hbox.getChildren().add(new Label("Kein Rezept für den Tag geplant"));
		        hbox.setAlignment(Pos.CENTER);
		        tab.setContent(hbox);
			}
			einkaufszettel.getTabs().add(tab);
		}
		
		
		//schlaue Liste 
		// gleiche Artikel werden an dem ersten Einkaufstag zusammengeführt und aus den anderen listen entfernt.
		// liste für den ersten Tag --> beinhaltet alle gleiche Artikel und die für den ersten Tag
		// liste läuft in eine Richtung --> die überprüften brauchen nicht nochmal geprüft werden !!
		// gefundene Rezepte werden mit der überprüften verrechnet und gelöscht --> suche geht bis zum ende weiter
		// 
		
		ArrayList<Zutat> schlaueListe = new ArrayList<Zutat>();
		
		/*ArrayList<Zutat> tag1 = new ArrayList<Zutat>();
		ArrayList<Zutat> tag2 = new ArrayList<Zutat>();
		ArrayList<Zutat> tag3 = new ArrayList<Zutat>();
		ArrayList<Zutat> tag4 = new ArrayList<Zutat>();
		ArrayList<Zutat> tag5 = new ArrayList<Zutat>();
		*/
		
		Map<Integer, Zutat> zutatenliste = new HashMap<Integer, Zutat>();

		int j = 100;
		
		for(int i = 0; i < MainUebersichtController.data.length; i++){
			j = 0;
			j = ( i + 1 ) * 100;
			if(MainUebersichtController.data[i] != null){
				String rezeptid = (String) MainUebersichtController.data[i].get("rezept");
				
				url = "http://localhost:8080/rezept/" + rezeptid;
				String rezeptGet = HttpConnection.get(url);
				Object temp = JSONValue.parse(rezeptGet);
				JSONObject rezept = (JSONObject) temp;
				JSONArray zutatenRezept = (JSONArray) rezept.get("Zutaten");
				
				
				for(int k = 0; k < zutatenRezept.size(); k++){
					JSONObject tempZ = (JSONObject) zutatenRezept.get(k);
					String name = (String) tempZ.get("name");
					String menge = (String) tempZ.get("menge");
					String mengenangabe = (String) tempZ.get("mengenangabe");
				
					zutatenliste.put(j++, new Zutat(name, menge, mengenangabe));
					System.out.println(j);
					System.out.println(name);
				}	
			}
			
		}
		
		int length = zutatenliste.size();
		System.out.println(length);
		
		int g;
		boolean test1 = true;
		boolean test2 = true;
		for(int i = 0; i < 5; i++){
			//die erste tag1 iterieren
			
			j = ( i + 1 ) * 100;
			
			for(int k = i + 1; k < 5; k++){
				//vergleich von zutatenliste<0,zutat.name> == zutatenliste<1,zutat.name>
				g = (k + 1) * 100;
				test1 = true;
				System.out.println("g: " + g);
				while(test1){
					if(zutatenliste.get(j) == null){
						test1 = false;
					} else if(zutatenliste.get(g) == null){
						g = (k + 1) * 100;
						j++;
					} else {

						String tempj = zutatenliste.get(j).getName();
						String tempg = zutatenliste.get(g).getName();
						System.out.println(tempj + " j: " + j);
						System.out.println(tempg + " g: " + g);
						if(tempj.equals(tempg)){
							String tempMengej = zutatenliste.get(j).getMenge();
							String tempMengeg = zutatenliste.get(g).getMenge();
							if(tempMengej.equals("-")){
								tempMengej = "0";
							}
							if(tempMengeg.equals("-")){
								tempMengeg = "0";
							}
							
							int tempMengejInt = Integer.parseInt(tempMengej);
							int tempMengegInt = Integer.parseInt(tempMengeg);
							Integer newMenge = tempMengejInt + tempMengegInt;
							String newMengeTemp = newMenge.toString();
							
							zutatenliste.get(j).setMenge(newMengeTemp);
							int temp = g;
							int tempNext = g + 1;
							test2 = true;
							while(test2){
								if(zutatenliste.get(tempNext) == null){
									test2 = false;
								} else {
									zutatenliste.remove(temp);
									Zutat nextZutat = new Zutat("test", "test", "test");
									nextZutat = zutatenliste.get(tempNext);
									System.out.println(nextZutat.getName() + " ich bin hier!");
									zutatenliste.put(temp, nextZutat);
									temp++;
									System.out.println(temp + "--> temp");
									tempNext++;
									System.out.println(tempNext + "--> tempNext");
								}
								
							}
							
						}
					}
					g++;
				}
				
				j++;
			}
		}
		
		TableView<Zutat> tabelle = new TableView<Zutat>();
		ObservableList<Zutat> data = FXCollections.observableArrayList();
		Tab tab = new Tab();
		tab.setText("Schlaue Liste");
		TableColumn wochentagSpalte0 = new TableColumn(MainUebersichtController.wochentag[0]);
		TableColumn wochentagSpalte1 = new TableColumn(MainUebersichtController.wochentag[1]);
		TableColumn wochentagSpalte2 = new TableColumn(MainUebersichtController.wochentag[2]);
		TableColumn wochentagSpalte3 = new TableColumn(MainUebersichtController.wochentag[3]);
		TableColumn wochentagSpalte4 = new TableColumn(MainUebersichtController.wochentag[4]);

		
		
		
		for(int i = 0; i < 5; i++){
			j = 0;
			j = ( i + 1 ) * 100;
			while(zutatenliste.get(j) != null){
				Zutat temp = zutatenliste.get(j);
				
				data.add(temp);
				tabelle.setItems(data);
				//System.out.println(temp.getName());
				j++;
			}
			
			
			TableColumn zutatName = new TableColumn("Zutat");
			zutatName.setCellValueFactory(new PropertyValueFactory<Zutat, String>("name"));
			
			TableColumn zutatMenge = new TableColumn("Menge");
			zutatMenge.setCellValueFactory(new PropertyValueFactory<Zutat, String>("menge"));
			
			TableColumn zutatMengenangabe = new TableColumn("Mengenangabe");
			zutatMengenangabe.setCellValueFactory(new PropertyValueFactory<Zutat, String>("mengenangabe"));
		
		
		
			if(i == 0){
				
				wochentagSpalte0.getColumns().addAll(zutatName, zutatMenge, zutatMengenangabe);
			} else if (i == 1){

				wochentagSpalte1.getColumns().addAll(zutatName, zutatMenge, zutatMengenangabe);	
			} else if (i == 2){
		
				wochentagSpalte2.getColumns().addAll(zutatName, zutatMenge, zutatMengenangabe);	
			} else if (i == 3){
				
				wochentagSpalte3.getColumns().addAll(zutatName, zutatMenge, zutatMengenangabe);	
			} else if (i == 4){
				wochentagSpalte4.getColumns().addAll(zutatName, zutatMenge, zutatMengenangabe);	
			} 
		}
		
		tabelle.getColumns().addAll(wochentagSpalte0, wochentagSpalte1, wochentagSpalte2, wochentagSpalte3, wochentagSpalte4);
		einkaufszettel.getTabs().add(tab);
		
		
		//gesamte Liste
		// alle gleichen Artikel werden zusammengefasst und die mengen addiert
		
		
		/*
		
		url = "http://localhost:8080/user/" + id + "/einkaufszettel"; 
		String einkaufslisteGet = HttpConnection.get(url);
		Object temp = JSONValue.parse(einkaufslisteGet);
		JSONObject temp2 = (JSONObject) temp;
		zettel = (JSONArray) temp2.get("Montag");
	        
		}*/
	}
	
	
	@FXML
	private void zurueck() throws IOException{
		RESTkoch.stage.setScene(RESTkoch.mainUebersicht);
	}
	
	@FXML
	private void addLebensmittel() throws IOException{
		RESTkoch.stage.setScene(RESTkoch.mainUebersicht);
	}


	
	public static class Zutat {
		
		private final SimpleStringProperty name;
        private final SimpleStringProperty menge;
        private final SimpleStringProperty mengenangabe;
 
        private Zutat(String name, String menge, String mengenangabe) {
            this.name = new SimpleStringProperty(name);
            this.menge = new SimpleStringProperty(menge);
            this.mengenangabe = new SimpleStringProperty(mengenangabe);
        }
 
        public String getName() {
            return name.get();
        }
 
        public String getMenge() {
            return menge.get();
        }
 
        public String getMengenangabe() {
            return mengenangabe.get();
        }
        
        public void setName(String newName){
        	name.set(newName);
        }
        
        public void setMenge(String newMenge){
        	menge.set(newMenge);
        }
        
        public void setMengenangabe(String newMengeangabe){
        	mengenangabe.set(newMengeangabe);
        }
        
		
	}
}
