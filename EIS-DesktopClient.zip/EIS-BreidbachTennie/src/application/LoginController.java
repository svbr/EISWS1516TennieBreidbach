package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import application.RESTkoch;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController implements Initializable{
	
	RESTkoch rKoch = new RESTkoch();
	HttpConnection http = new HttpConnection();
	
	@FXML
	private TextField emailAdresse;
	@FXML
	private PasswordField passwort;
	@FXML
	private Label fehler;
	
	public static String userId = " ";

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
		emailAdresse.setText("peter123@testmail.com");
		passwort.setText("qwertz");
	}
	
	@FXML
    private void login(ActionEvent event) throws IOException{
		String url = "http://localhost:8080/users";
		String email = emailAdresse.getText();
		String pwd = passwort.getText();

		if(pwd.isEmpty() || email.isEmpty()){
			fehler.setText("Bitte geben Sie ihre Emailadresse und ihr Passwort ein!");
		} else {
			String getUsers = http.get(url);
			
			Object temp = JSONValue.parse(getUsers);
			JSONArray users=(JSONArray) temp;
			
			for(int i = 0; i < users.size(); i++){
				JSONObject user = (JSONObject) users.get(i);
				if(user.get("Email").equals(email) && user.get("Passwort").equals(pwd)){
					userId = (String) user.get("_id");
					rKoch.loadMainview();
					RESTkoch.stage.setScene(RESTkoch.mainUebersicht);
				}
			}
			fehler.setText("Die Email oder das Passwort ist falsch!");
		}
    }
	@FXML
    private void registrieren(ActionEvent event) throws IOException{
		
    	//RESTkoch.stage.setScene(RESTkoch.mainUebersicht);
    }
	
}
