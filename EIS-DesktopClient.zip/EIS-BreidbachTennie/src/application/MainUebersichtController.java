package application;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar; 

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import application.RESTkoch;
import application.LoginController;
import application.HttpConnection;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;


public class MainUebersichtController implements Initializable{

	RESTkoch rKoch = new RESTkoch();
	HttpConnection http = new HttpConnection();
	
	@FXML
	private Button tagAdd1;
	@FXML
	private Button tagAdd2;
	@FXML
	private Button tagAdd3;
	@FXML
	private Button tagAdd4;
	@FXML
	private Button tagAdd5;
	
	@FXML
	private Hyperlink tagName1;
	@FXML
	private Hyperlink tagName2;
	@FXML
	private Hyperlink tagName3;
	@FXML
	private Hyperlink tagName4;
	@FXML
	private Hyperlink tagName5;
	
	private JSONArray einkaufszettel;
	private JSONArray lebensmittelbestand;
	private JSONArray wochenplan;
	static JSONObject [] data = new JSONObject [5];
	
	public static String [] datum;
	public static String [] wochentag;
	public static String ausgewaehltesDatum;
	public static String ausgewaehlterWochentag;
	public static String ausgewaehltesRezept;
	public static boolean fromMain;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		// Überprüfen ob Einkaufsliste vorhanden ist (get)
		// Überprüfen ob Lebensmittelreste vorhanden sind (get)
		// Wochenplan (get)
		// ggf bestimmte plus_x verhindern und Rezeptverlinkung einbinden
		String id = LoginController.userId;
		System.out.println("userid: " + id);
		
		String url = "http://localhost:8080/user/" + id + "/einkaufszettel"; 
		String einkaufslisteGet = HttpConnection.get(url);
		Object temp = JSONValue.parse(einkaufslisteGet);
		JSONObject temp2 = (JSONObject) temp;
		einkaufszettel = (JSONArray) temp2.get("Montag");
		
		url = "http://localhost:8080/user/" + id + "/lebensmittelbestand";
		String lebensmittelbestandGet = HttpConnection.get(url);
		temp = JSONValue.parse(lebensmittelbestandGet);
		temp2 = (JSONObject) temp;
		lebensmittelbestand = (JSONArray) temp2.get("lebensmittelbestand");
		
		url = "http://localhost:8080/user/" + id + "/wochenplan";
		String wochenplanGet = HttpConnection.get(url);
		temp = JSONValue.parse(wochenplanGet);
		temp2 = (JSONObject) temp;
		wochenplan = (JSONArray) temp2.get("wochenplan");
		
		tagName1.setVisible(false);
		tagName2.setVisible(false);
		tagName3.setVisible(false);
		tagName4.setVisible(false);
		tagName5.setVisible(false);
		

		GregorianCalendar now = new GregorianCalendar();
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		int tag;
		
		datum = new String[5];
		wochentag = new String[5];
		for(int i = 0; i < datum.length; i++){
			datum[i] = df.format(now.getTime()).toString();
			tag = now.get(Calendar.DAY_OF_WEEK);
			switch (tag) {
				case 2:
					wochentag[i] = "Montag";
					break;
				case 3:
					wochentag[i] = "Dienstag";
					break;
				case 4:
					wochentag[i] = "Mittwoch";
					break;
				case 5:
					wochentag[i] = "Donnerstag";
					break;
				case 6:
					wochentag[i] = "Freitag";
					break;
				case 7:
					wochentag[i] = "Samstag";
					break;
				case 1:
					wochentag[i] = "Sonntag";
					break;
			}
			now.add(Calendar.DAY_OF_MONTH, 1);
		}

		boolean keinenTag = true;
		
		for(int k = 0; k < datum.length; k++){
			keinenTag = true;
			for(int i = 0; i < wochenplan.size(); i++){
				JSONObject tempW = (JSONObject) wochenplan.get(i);
				if(tempW.get("datum").equals(datum[k])){
					keinenTag = false;
					data[k] = tempW;
					
					i = wochenplan.size();
					switch (k) {
						case 0:	
							tagAdd1.setDefaultButton(true);
							tagAdd1.setVisible(false);
							tagName1.setVisible(true);
							tagName1.setText((String) tempW.get("tag"));
							break;
						case 1:
							tagAdd2.setDefaultButton(true);
							tagAdd2.setVisible(false);
							tagName2.setVisible(true);
							tagName2.setText((String) tempW.get("tag"));
							break;
						case 2:
							tagAdd3.setDefaultButton(true);
							tagAdd3.setVisible(false);
							tagName3.setVisible(true);
							tagName3.setText((String) tempW.get("tag"));
							break;
						case 3:
							tagAdd4.setDefaultButton(true);
							tagAdd4.setVisible(false);
							tagName4.setVisible(true);
							tagName4.setText((String) tempW.get("name"));
							break;
						case 4:
							tagAdd5.setDefaultButton(true);
							tagAdd5.setVisible(false);
							tagName5.setVisible(true);
							tagName5.setText((String) tempW.get("tag"));
							break;
					}
				}
			}
			if(keinenTag){
				data[k] = null;
			}
		}
	}
	
	@FXML
	private void plus_1 (ActionEvent event) throws IOException{
		//1. Abfrage ob Lebensmittelreste vorhanden sind
		//2. (true) --> Resteverwertung
		//2. (false) --> Rezeptsuche
		
		
		ausgewaehltesDatum = datum[0];
		ausgewaehlterWochentag = wochentag[0];
		
		if(lebensmittelbestand.size() == 0){
			RESTkoch.stage.setScene(RESTkoch.rezeptsuche);
		} else {
			rKoch.loadResteverwertung();
			RESTkoch.stage.setScene(RESTkoch.resteverwertung);
		}
		
	}
	
	@FXML
	private void plus_2 (ActionEvent event) throws IOException{
		//1. Abfrage ob Lebensmittelreste vorhanden sind
		//2. (true) --> Resteverwertung
		//2. (false) --> Rezeptsuche
		
		ausgewaehltesDatum = datum[1];
		ausgewaehlterWochentag = wochentag[1];
		
		if(lebensmittelbestand.size() == 0){
			RESTkoch.stage.setScene(RESTkoch.rezeptsuche);
		} else {
			rKoch.loadResteverwertung();
			RESTkoch.stage.setScene(RESTkoch.resteverwertung);
		}
	}
	
	@FXML
	private void plus_3 (ActionEvent event) throws IOException{
		//1. Abfrage ob Lebensmittelreste vorhanden sind
		//2. (true) --> Resteverwertung
		//2. (false) --> Rezeptsuche	
		
		ausgewaehltesDatum = datum[2];
		ausgewaehlterWochentag = wochentag[2];
		
		if(lebensmittelbestand.size() == 0){
			RESTkoch.stage.setScene(RESTkoch.rezeptsuche);
		} else {
			rKoch.loadResteverwertung();
			RESTkoch.stage.setScene(RESTkoch.resteverwertung);
		}
	}
	
	@FXML
	private void plus_4 (ActionEvent event) throws IOException{
		//1. Abfrage ob Lebensmittelreste vorhanden sind
		//2. (true) --> Resteverwertung
		//2. (false) --> Rezeptsuche
		
		ausgewaehltesDatum = datum[3];
		ausgewaehlterWochentag = wochentag[3];
		
		if(lebensmittelbestand.size() == 0){
			RESTkoch.stage.setScene(RESTkoch.rezeptsuche);
		} else {
			rKoch.loadResteverwertung();
			RESTkoch.stage.setScene(RESTkoch.resteverwertung);
		}
	}

	@FXML
	private void plus_5 (ActionEvent event) throws IOException{
		//1. Abfrage ob Lebensmittelreste vorhanden sind
		//2. (true) --> Resteverwertung
		//2. (false) --> Rezeptsuche
		
		ausgewaehltesDatum = datum[4];
		ausgewaehlterWochentag = wochentag[4];
		
		if(lebensmittelbestand.size() == 0){
			RESTkoch.stage.setScene(RESTkoch.rezeptsuche);
		} else {
			rKoch.loadResteverwertung();
			RESTkoch.stage.setScene(RESTkoch.resteverwertung);
		}
	}
	
	@FXML
	private void logout (ActionEvent event) throws IOException{
		// zurück auf login-fenster
		rKoch.loadLogin();
		RESTkoch.stage.setScene(RESTkoch.login);
	}
	
	@FXML
	private void einkaufsliste (ActionEvent event) throws IOException{
		//in das Einkaufslistenfenster
		rKoch.loadEinkaufszettel();
		RESTkoch.stage.setScene(RESTkoch.einkaufszettel);
	}
	
	@FXML
	private void lebensmittelbestand (ActionEvent event) throws IOException{
		//in das Lebensmittelbestandsfenster
		rKoch.loadLebensmittelbestand();
		RESTkoch.stage.setScene(RESTkoch.lebensmittelbestand);
	}
	
	@FXML
	private void tipps (ActionEvent event) throws IOException{
		//in das Tippfenster
	}
	
	@FXML
	private void einstellungen (ActionEvent event) throws IOException{
		//(in das Einstellungsfenster)
	}
	
	@FXML
	private void druckenWochenplan (ActionEvent event) throws IOException{
		//(Druckvorgang starten)
	}
	
	@FXML
	private void rezeptTag1 (ActionEvent event) throws IOException{
		String rezeptId = (String) data[0].get("rezept");
		ausgewaehltesRezept = rezeptId;
		fromMain = true;
		rKoch.loadRezepte();
		RESTkoch.stage.setScene(RESTkoch.rezepte);
	}
	
	@FXML
	private void rezeptTag2 (ActionEvent event) throws IOException{
		String rezeptId = (String) data[1].get("rezept");
		ausgewaehltesRezept = rezeptId;
		fromMain = true;
		rKoch.loadRezepte();
		RESTkoch.stage.setScene(RESTkoch.rezepte);
		
	}
	
	@FXML
	private void rezeptTag3 (ActionEvent event) throws IOException{
		String rezeptId = (String) data[2].get("rezept");
		ausgewaehltesRezept = rezeptId;
		fromMain = true;
		rKoch.loadRezepte();
		RESTkoch.stage.setScene(RESTkoch.rezepte);
	}
	
	@FXML
	private void rezeptTag4 (ActionEvent event) throws IOException{
		String rezeptId = (String) data[3].get("rezept");
		ausgewaehltesRezept = rezeptId;
		fromMain = true;
		rKoch.loadRezepte();
		RESTkoch.stage.setScene(RESTkoch.rezepte);
	}
	
	@FXML
	private void rezeptTag5 (ActionEvent event) throws IOException{
		String rezeptId = (String) data[4].get("rezept");
		ausgewaehltesRezept = rezeptId;
		fromMain = true;
		rKoch.loadRezepte();
		RESTkoch.stage.setScene(RESTkoch.rezepte);
	}
	
	
	
}
