package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.TimeZone;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import application.RESTkoch;
import application.HttpConnection;
import application.Rezept;
import application.MainUebersichtController;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.ListView;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.util.Callback;
import javafx.util.converter.LongStringConverter;

public class ResteverwertungController implements Initializable{

	RESTkoch rKoch = new RESTkoch();
	MainUebersichtController test = new MainUebersichtController();

	ObservableList<Rezept> data = FXCollections.observableArrayList();
	
	@FXML
	private TableView<Rezept> tabelle1;
	
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		// Lebensmittelbestand abrufen (get --> /user/:id/lebensmittelbestand)
		// Lebensmittelbestand verwertbar speichern
		// Rezepte mit resten vergleichen (get --> /rezepte?reste=bla&menge=x)
		// Tabelle vorbereiten und mit Ergebnissen füllen
		// !!! Ergebnisse mit link zu rezeptfenster verknüpfen!!!!
		String id = LoginController.userId;
		
		String url = "http://localhost:8080/user/" + id + "/lebensmittelbestand";
		String lebensmittelbestandGet = HttpConnection.get(url);
		Object temp = JSONValue.parse(lebensmittelbestandGet);
		JSONObject temp2 = (JSONObject) temp;
		JSONArray lebensmittelbestand = (JSONArray) temp2.get("lebensmittelbestand");
		
		String reste = "";
		String menge = "";
		for(int i = 0; i < lebensmittelbestand.size(); i++){
			JSONObject tempL = (JSONObject) lebensmittelbestand.get(i);
			if (i == 0){
				reste = reste + tempL.get("name");
				menge = menge + tempL.get("menge");
			} else {
				reste = reste + "+" + tempL.get("name");
				menge = menge + "+" + tempL.get("menge");
			}
		}
		
		url = "http://localhost:8080/rezepte?reste=" + reste + "&menge=" + menge;
		System.out.println(url);
		
		String rezepteGet = HttpConnection.get(url);
		temp = JSONValue.parse(rezepteGet);
		JSONArray rezepte = (JSONArray) temp;
		
		System.out.println(rezepte.size() + " rezepte zu den resten gefunden");
		for(int i = 0; i < rezepte.size(); i++){
			JSONObject tempT = (JSONObject) rezepte.get(i);
			tabelleFuellen(tempT);
		}
		
		
		Callback<TableColumn, TableCell> stringCellFactory =
                new Callback<TableColumn, TableCell>() {
            @Override
            public TableCell call(TableColumn p) {
                MyStringTableCell cell = new MyStringTableCell();
                cell.addEventFilter(MouseEvent.MOUSE_CLICKED, new MyEventHandler());
                return cell;
            }
        };
		
		TableColumn rezeptID = new TableColumn("ID des Rezeptes");
		rezeptID.setCellValueFactory(new PropertyValueFactory<Rezept, String>("id"));
		rezeptID.setCellFactory(stringCellFactory);
		
		TableColumn rezeptTitel = new TableColumn("Titel des Rezeptes");
		rezeptTitel.setCellValueFactory(new PropertyValueFactory<Rezept, String>("titel"));
		rezeptTitel.setCellFactory(stringCellFactory);
		
		TableColumn rezeptSchwierigkeitsgrad = new TableColumn("Schwierigkeitsgrad");
		rezeptSchwierigkeitsgrad.setCellValueFactory(new PropertyValueFactory<Rezept, String>("schwierigkeitsgrad"));
		rezeptSchwierigkeitsgrad.setCellFactory(stringCellFactory);
		
		TableColumn rezeptDauer = new TableColumn("Zeitbedarf");
		rezeptDauer.setCellValueFactory(new PropertyValueFactory<Rezept, String>("dauer"));
		rezeptDauer.setCellFactory(stringCellFactory);
		
		tabelle1.getColumns().addAll(rezeptID, rezeptTitel, rezeptSchwierigkeitsgrad, rezeptDauer);
		
	}
	
	private void tabelleFuellen(JSONObject row){
		String id = (String) row.get("_id");
		String titel = (String) row.get("Titel");
		String schwierigkeitsgrad = (String) row.get("Schwierigkeitsgrad");
		String dauer = (String) row.get("Zeitbedarf");		
		
		data.add(new Rezept(id, titel, schwierigkeitsgrad, dauer));
        int groeßetabelle1 = data.size();

        tabelle1.setItems(data);
	}
	
	
	@FXML
	private void lebensmittelbestand(ActionEvent event) throws IOException{
		//zum Lebensmittelbestandsfenster
	} 
	
	@FXML
	private void rezeptsuche(ActionEvent event) throws IOException{
		//zum rezeptsuchfenster
		RESTkoch.stage.setScene(RESTkoch.rezeptsuche);
	}
		
	@FXML
	private void rezeptVorschlaegeReste(ActionEvent event) throws IOException{
		//zum rezeptsuchfenster	
	}
	
	class MyStringTableCell extends TableCell<Rezept, String> {
		 
        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty ? null : getString());
            setGraphic(null);
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
    }
	
	class MyEventHandler implements EventHandler<MouseEvent> {
		 
        @Override
        public void handle(MouseEvent t) {
            TableCell c = (TableCell) t.getSource();
            int index = c.getIndex();
            System.out.println("id = " + data.get(index).getId());
            System.out.println("titel = " + data.get(index).getTitel());
            System.out.println("Schwierigkeitsgrad = " + data.get(index).getSchwierigkeitsgrad());
            System.out.println("Dauer = " + data.get(index).getDauer());
            
            test.ausgewaehltesRezept = data.get(index).getId();
            try {
            	MainUebersichtController.fromMain = false;
				rKoch.loadRezepte();
				RESTkoch.stage.setScene(RESTkoch.rezepte);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
        }
    }
	
}
