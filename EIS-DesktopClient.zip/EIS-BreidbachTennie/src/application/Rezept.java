package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Rezept {
	
	private final SimpleStringProperty id;
	private final SimpleStringProperty titel;
	private final SimpleStringProperty schwierigkeitsgrad;
	private final SimpleStringProperty dauer;
	
	public Rezept(String id, String titel, String schwierigkeitsgrad, String dauer){
		this.id = new SimpleStringProperty(id);
		this.titel = new SimpleStringProperty(titel);
		this.schwierigkeitsgrad = new SimpleStringProperty(schwierigkeitsgrad);
		this.dauer = new SimpleStringProperty(dauer);
	}
	
	public String getTitel(){
		return titel.get();
	}
	
	public String getId(){
		return id.get();
	}
	
	public String getSchwierigkeitsgrad(){
		return schwierigkeitsgrad.get();
	}
	
	public String getDauer(){
		return dauer.get();
	}
	
}
