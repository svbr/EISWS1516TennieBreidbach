package com.example.sven.restkoch;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import cz.msebera.android.httpclient.HttpResponse;

import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.HttpResponse;

import android.os.AsyncTask;
import android.util.Log;
/**
 * Created by Sven on 24.11.2015.
 */
public class AsyncHttpTask extends AsyncTask<String, Void, String>{
    private HttpHandler httpHandler;
    public AsyncHttpTask(HttpHandler httpHandler){
        this.httpHandler = httpHandler;
    }

    @Override
    protected String doInBackground(String... arg0) {
        InputStream inputStream = null;
        String result = "";
        try {

            // HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // http request
            HttpResponse httpResponse = httpclient.execute(httpHandler.getHttpRequestMethod());

            // response erhalten als inputStream
            inputStream = httpResponse.getEntity().getContent();

            // inputstream convertieren zu string
            if(inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Funktioniert nicht!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        return result;
    }
    @Override
    protected void onPostExecute(String result) {
        httpHandler.onResponse(result);
    }

    //--------------------------------------------------------------------------------------------
    private static String convertInputStreamToString(InputStream inputStream) throws IOException{
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;
    }
}
