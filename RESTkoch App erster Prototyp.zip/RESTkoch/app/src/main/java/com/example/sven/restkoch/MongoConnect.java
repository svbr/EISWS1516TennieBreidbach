package com.example.sven.restkoch;

import java.net.*;
import java.io.*;

import java.util.ArrayList;
import java.util.List;
//import org.apache.http.*;


import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.sven.restkoch.MainActivity;

import com.squareup.okhttp.*;

/**
 * Created by Sven on 23.11.2015.
 */

// TODO !WIRD NICHT MEHR BENÖTIGT!

public class MongoConnect {



    public MongoConnect(){

    }
    public String test(){
        return get("http://10.3.57.200:8080/test");
    }

    public static String get(String targetURL){
        URL url = null;
        HttpURLConnection connection = null;
        try {
            //Verbindung wird erstellt (GET)
            url = new URL(targetURL);
            connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");

            //Response wird erwartet und die Übertragenden Daten werden gespeichert
            InputStream input = connection.getInputStream();
            BufferedReader tempBuffer = new BufferedReader(new InputStreamReader(input));
            String line;
            StringBuffer response = new StringBuffer();
            //StringBuilder response = new StringBuilder();

            while((line = tempBuffer.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }

            tempBuffer.close();
            return response.toString();

        } catch (Exception e) {

            e.printStackTrace();
            return null;

        } finally {

            if(connection != null) {
                connection.disconnect();
            }
        }
    }

}