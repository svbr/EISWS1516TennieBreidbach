package com.example.sven.restkoch;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sven.restkoch.HttpHandler;

import java.net.*;
import java.io.*;

import com.squareup.okhttp.*;

import com.example.sven.restkoch.MainActivityOnClickListener;
import com.example.sven.restkoch.MongoConnect;

import cz.msebera.android.httpclient.client.methods.HttpGet;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;

public class MainActivity extends AppCompatActivity {

    //Declaration und Initialisierung von Widgets

    //Constante
    private static final String MSG_Erfolg ="Ihr Rezept wird geladen";
    private static final boolean DEVELOPER_MODE = false ;

    //Textview
    private TextView txtvOutput = null;
    private TextView txtvOutput2 = null;
    private TextView txtvOutout3 = null;


    //Buttons
    private Button cmdNeuRezept = null;

    //Listener
    private static MainActivityOnClickListener mainActivityOnClickListener = null;

    //StrictMode
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        if (DEVELOPER_MODE) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                    .detectDiskReads()
                    .detectDiskWrites()
                    .detectNetwork()
                    .penaltyLog()
                    .build());
        }
        super.onCreate(savedInstanceState);

        /*
        * Generierung des Textviews / Widgets
        * Alle Widgets die im Designer angelegt werden,
        * bekommen eine ausgewählte ID. Die ID wird in
        * der R-Datei als Ganzzahl hinterlegt.
        * So können wir bei Bedarf darauf zugreifen.
        * Damit Android auch weiß, welches Widget aus
        * der ID generiert werden soll, setzen wir den
        * Typ des Widgets in Klammern davor.
         */

        //Setzen des Layouts
        setContentView(R.layout.main_activity_layout);

        //Textview
        this.txtvOutput = (TextView) findViewById(R.id.txtvOutput);
        this.txtvOutput2 = (TextView) findViewById(R.id.txtvOutput2);
        this.txtvOutout3 = (TextView) findViewById(R.id.txtvOutput3);


        //Button
        this.cmdNeuRezept = (Button) findViewById(R.id.cmdNeuRezept);

        //Listener wenn der Button geklickt wird

        /*Listener ausgelagert (Besser):
        mainActivityOnClickListener = new MainActivityOnClickListener();

        cmdNeuRezept.setOnClickListener(mainActivityOnClickListener);
        */

        cmdNeuRezept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Popup Nachricht
                Toast.makeText(v.getContext(),MSG_Erfolg,Toast.LENGTH_SHORT).show();
                //TODO get auf MongoDB
                /*mongoConnect = new MongoConnect();
                String bla = mongoConnect.test();
                System.out.print(bla);*/

                // Aufruf des Handlers
                new HttpHandler() {
                    @Override
                    public HttpUriRequest getHttpRequestMethod() {
                        // Adresse des Servers übergeben
                        return new HttpGet("http://10.3.57.200:8080/test");

                        // return new HttpPost(url)
                    }

                    // Ausgabe es Rezepts in ein Textfeld mit einem Popup zur Bestätigung
                    @Override
                    public void onResponse(String result) {
                        Toast.makeText(getBaseContext(), "Rezept erhalten", Toast.LENGTH_SHORT).show();
                        txtvOutout3.setText(result);
                        }

                }.execute();
            }
        });



        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        /*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
