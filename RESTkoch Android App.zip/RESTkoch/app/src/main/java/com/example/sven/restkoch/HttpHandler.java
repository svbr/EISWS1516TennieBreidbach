package com.example.sven.restkoch;

import com.example.sven.restkoch.AsyncHttpTask;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;
/**
 * Created by Sven on 24.11.2015.
 */
public abstract class HttpHandler {
    public abstract HttpUriRequest getHttpRequestMethod();

    public abstract void onResponse(String result);

    public void execute(){
        new AsyncHttpTask(this).execute();
    }

}
