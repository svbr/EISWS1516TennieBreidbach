package com.example.sven.restkoch;

import android.view.View;
import android.widget.Toast;

/**
 * Created by Sven on 23.11.2015.
 */

public class MainActivityOnClickListener implements View.OnClickListener{

    private static final String MSG_Erfolg ="Ihr Rezept wird geladen";
    //MainActivity
    private static MainActivity mainActivity = null;


    public MainActivityOnClickListener()
    {
        //Hier gibt es nichts zu tun
    }

    @Override
    public void onClick(View v)
    {
        mainActivity = ((MainActivity) v.getContext());
        generateWidgetReferences();

        switch (v.getId())
        {
            case R.id.cmdLMBestand:
                Toast.makeText(v.getContext(),MSG_Erfolg,Toast.LENGTH_LONG).show();
                break;
        }
    }

    private void generateWidgetReferences() {

    }


}

//switch case welcher button geklickt wurde