package com.example.sven.restkoch;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import cz.msebera.android.httpclient.client.methods.HttpGet;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;

public class MainActivity extends AppCompatActivity {

    //Declaration und Initialisierung von Widgets

    //Constante
    private static final String MSG_Erfolg ="Ihr Rezept wird geladen";
    private static final boolean DEVELOPER_MODE = false ;

    //Textview
    private TextView txtvOutput = null;
    private TextView txtvOutput2 = null;
    //private TextView txtvOutout3 = null;


    //Buttons
    private Button cmdLMBestand = null;
    private Button cmdEinkaufszettel = null;

    private ImageButton imageButton1 =null;
    private ImageButton imageButton2 =null;
    private ImageButton imageButton3 =null;
    private ImageButton imageButton4 =null;
    private ImageButton imageButton5 =null;
    private ImageButton imageButton6 =null;
    private ImageButton imageButton7 =null;

    //Scrollview
    private HorizontalScrollView horizontalScrollView1=null;

    //Listener
    private static MainActivityOnClickListener mainActivityOnClickListener = null;

    //StrictMode
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        if (DEVELOPER_MODE) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                    .detectDiskReads()
                    .detectDiskWrites()
                    .detectNetwork()
                    .penaltyLog()
                    .build());
        }
        super.onCreate(savedInstanceState);

        /*
        * Generierung des Textviews / Widgets
        * Alle Widgets die im Designer angelegt werden,
        * bekommen eine ausgewählte ID. Die ID wird in
        * der R-Datei als Ganzzahl hinterlegt.
        * So können wir bei Bedarf darauf zugreifen.
        * Damit Android auch weiß, welches Widget aus
        * der ID generiert werden soll, setzen wir den
        * Typ des Widgets in Klammern davor.
         */

        //Setzen des Layouts
        setContentView(R.layout.main_activity_layout);

        //Textview
        this.txtvOutput = (TextView) findViewById(R.id.txtvOutput);
        this.txtvOutput2 = (TextView) findViewById(R.id.txtvOutput2);
        //this.txtvOutout3 = (TextView) findViewById(R.id.txtvOutput3);


        //Buttons
        this.cmdLMBestand = (Button) findViewById(R.id.cmdLMBestand);
        this.cmdEinkaufszettel = (Button) findViewById(R.id.cmdEinkaufszettel);

        cmdLMBestand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, LMBestandActivity.class);
                startActivity(intent);
            }
        });

        cmdEinkaufszettel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, EinkaufszettelActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton1 = (ImageButton) findViewById(R.id.imageButton1);

        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton2 = (ImageButton) findViewById(R.id.imageButton2);

        imageButton2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton3 = (ImageButton) findViewById(R.id.imageButton3);

        imageButton3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton4 = (ImageButton) findViewById(R.id.imageButton4);

        imageButton4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton5 = (ImageButton) findViewById(R.id.imageButton5);

        imageButton5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton6 = (ImageButton) findViewById(R.id.imageButton6);

        imageButton6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        this.imageButton7 = (ImageButton) findViewById(R.id.imageButton7);

        imageButton7.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, RezeptAnsichtActivity.class);
                startActivity(intent);
            }
        });

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
