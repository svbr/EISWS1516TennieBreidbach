package com.example.sven.restkoch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import cz.msebera.android.httpclient.client.methods.HttpGet;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;


public class EinkaufszettelActivity extends AppCompatActivity {


    private static final String MSG_Erfolg ="Ihr Einkaufszettel wird geladen";
    private ListView listview1 = null;

    private Button cmdZettelladen =null;

    private TextView txtvOutout3 = null;

    private static final String MONTAG = "montag";
    private static final String NAME = "name";
    private static final String MENGE = "menge";
    private static final String MENGENANGABE = "mengenangabe";
    JSONArray einkaufszettel = null;
    ArrayList<HashMap<String, String>> zettelList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_einkaufszettel);

        zettelList = new ArrayList<HashMap<String,String>>();

        listview1 = (ListView) findViewById(R.id.listView1);
        this.cmdZettelladen = (Button)findViewById(R.id.cmdZettelladen);
        this.txtvOutout3 = (TextView)findViewById(R.id.txtvOutout3);
/*
        String[] einkaufszettelArray = new String[] {
                "Apfel - 4",
                "Hähnchenbrust - 500",
                "Tomaten - 8",
                "Salat - 200",
                "Brot - 1",
                "Hackfleisch - 250",
                "Zwiebel - 3",
                "Knoblauchzehen - 2",
                "Thunfisch - 250",
                "Pizzateig - 500",
                "Putenschnitzel - 500",
                "Frühlingszwiebel - 5",
                "Curry - 9",
                "Ananas - 150"
        };
*/          // Button umgehen mit Timer?
            cmdZettelladen.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                // Popup Nachricht
                                Toast.makeText(v.getContext(), MSG_Erfolg, Toast.LENGTH_SHORT).show();


                                // Aufruf des Handlers
                                new HttpHandler() {
                                        @Override
                                        public HttpUriRequest getHttpRequestMethod() {
                                                // Adresse des Servers übergeben
                                                return new HttpGet("http://10.3.129.125:8080/user/5697bed1670f15321064ead5/einkaufszettel");

                                                // return new HttpPost(url)
                                        }

                                        // Ausgabe es Rezepts in ein Textfeld mit einem Popup zur Bestätigung
                                        @Override
                                        public void onResponse(String result) {
                                                Toast.makeText(getBaseContext(), "geladen", Toast.LENGTH_SHORT).show();
                                                txtvOutout3.setText(result);

                                            try {
                                                JSONObject jObject = new JSONObject(result);
                                                einkaufszettel = jObject.getJSONArray(MONTAG);
                                                for (int i = 0; i < einkaufszettel.length(); i++) {
                                                    JSONObject c = einkaufszettel.getJSONObject(i);
                                                    String name = c.getString(NAME);
                                                    String menge = c.getString(MENGE);
                                                    String mengenangabe = c.getString(MENGENANGABE);

                                                    HashMap<String,String> montag = new HashMap<String, String>();
                                                    montag.put(NAME, name);
                                                    montag.put(MENGE, menge);
                                                    montag.put(MENGENANGABE, mengenangabe);

                                                    zettelList.add(montag);
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }



                                        }

                                    //@Override
                                   /* protected void onPostExecute(Void result) {

                                        ListAdapter adapter = new SimpleAdapter(
                                                MainActivity.this, zettelList,
                                                R.layout.activity_einkaufszettel, new String[] { NAME, MENGE,
                                                MENGENANGABE });
                                        listview1.setAdapter(adapter);
                                    }
*/
                                }.execute();
                        }
                });

            /*
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, android.R.id.text1, einkaufszettelArray);

            listview1.setAdapter(adapter);

            listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            SparseBooleanArray sparseBooleanArray = listview1.getCheckedItemPositions();
                            System.out.println("Clicked Position := " + position + " Value: " + sparseBooleanArray.get(position));

                            //CheckedTextView check = (CheckedTextView)view;
                            //check.setChecked(!check.isChecked());

                    }
            });
*/


    }
}
