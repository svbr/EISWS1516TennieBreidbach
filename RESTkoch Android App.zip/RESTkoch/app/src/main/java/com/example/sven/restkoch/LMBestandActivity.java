package com.example.sven.restkoch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class LMBestandActivity extends AppCompatActivity {

    private static final String MSG_Erfolg ="Der Lebensmittelbestand wird geladen";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lmbestand);



        // JSONparser für get vom Server




    }
}
