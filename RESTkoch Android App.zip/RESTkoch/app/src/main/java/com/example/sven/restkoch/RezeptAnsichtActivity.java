package com.example.sven.restkoch;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import cz.msebera.android.httpclient.client.methods.HttpGet;
import cz.msebera.android.httpclient.client.methods.HttpUriRequest;

public class RezeptAnsichtActivity extends AppCompatActivity {

    private Button cmdKochen = null;

    /*@Override
    public void onClick(View v) {
        if(v.getId() == R.id.imageButton1){
            Toast.makeText(v.getContext(), "Test", Toast.LENGTH_SHORT).show();
        }

    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rezept_ansicht);



/*
    public void onClick(View v) {
        // Popup Nachricht
        Toast.makeText(v.getContext(), "Test", Toast.LENGTH_SHORT).show();
        new HttpHandler() {
            @Override
            public HttpUriRequest getHttpRequestMethod() {
                // Adresse des Servers übergeben
                return new HttpGet("http://10.3.129.125:8080/user/5697bed1670f15321064ead5/einkaufszettel");


            }

        }
*/
    this.cmdKochen = (Button) findViewById(R.id.cmdKochen);
        cmdKochen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(RezeptAnsichtActivity.this, RezeptAnweisungenActivity.class);
                startActivity(intent);
            }
        });



    }


}
